﻿using GerenciadorDeTarefas.Communication.Responses;
using GerenciadorDeTarefas.Communication.Seed;

namespace GerenciadorDeTarefas.Application.UseCase.Tarefa.BuscarTarefa
{
    public class BuscarTarefaUseCase
    {
        public ResponseTarefaJson Execute(int id)
        {
            var retorno = SeedTarefas.Tarefas.FirstOrDefault(x => x.ID == id);

            return retorno;
        }

    }
}
