﻿using GerenciadorDeTarefas.Communication.Seed;

namespace GerenciadorDeTarefas.Application.UseCase.Tarefa.Apagar
{
    public class ApagarTarefaUseCase
    {
        public bool Execute(int id)
        {
            var indice = SeedTarefas.Tarefas.FindIndex(x => x.ID == id);
            if (indice == -1) 
            {
                return false;
            }
            else
            {
                SeedTarefas.Tarefas.RemoveAt(indice);
                return true;
            }

        }
    }
}
