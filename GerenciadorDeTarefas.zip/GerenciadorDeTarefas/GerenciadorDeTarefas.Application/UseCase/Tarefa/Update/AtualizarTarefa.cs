﻿using GerenciadorDeTarefas.Communication.Requests;
using GerenciadorDeTarefas.Communication.Seed;
using System.Net.Http.Headers;

namespace GerenciadorDeTarefas.Application.UseCase.Tarefa.Update
{
    public class AtualizarTarefa
    {
        public void Execute(RequestTarefaJson tarefa)
        {
            var trf = SeedTarefas.Tarefas.FirstOrDefault(x => x.ID == tarefa.ID);
            var index = SeedTarefas.Tarefas.FindIndex(x => x.ID == trf.ID);

            SeedTarefas.Tarefas[index].Status = tarefa.Status;
            SeedTarefas.Tarefas[index].DataLimite = tarefa.DataLimite;
            SeedTarefas.Tarefas[index].Descricao = tarefa.Descricao;
            SeedTarefas.Tarefas[index].Prioridade = tarefa.Prioridade;
            SeedTarefas.Tarefas[index].Nome = tarefa.Nome;
            
        }
    }
}
