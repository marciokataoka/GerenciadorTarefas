﻿using GerenciadorDeTarefas.Communication.Enums;
using GerenciadorDeTarefas.Communication.Requests;
using GerenciadorDeTarefas.Communication.Responses;
using GerenciadorDeTarefas.Communication.Seed;

namespace GerenciadorDeTarefas.Application.UseCase.Tarefa.Register
{
    public class RegisterTarefaUseCase
    {
        public ResponseRegisterTarefaJson Execute(RequestTarefaJson request)
        {
            var NovoId = SeedTarefas.Tarefas.Count+1;

            SeedTarefas.Tarefas.Add(
                new ResponseTarefaJson
                {
                    ID = NovoId,
                    Nome = $"{request.Nome}",
                    Descricao = $"{request.Descricao}",
                    DataLimite = request.DataLimite,
                    Prioridade = request.Prioridade,
                    Status = request.Status,
                }
            );

            return new ResponseRegisterTarefaJson { Id = NovoId, Name = request.Nome };
        }

    }
}
