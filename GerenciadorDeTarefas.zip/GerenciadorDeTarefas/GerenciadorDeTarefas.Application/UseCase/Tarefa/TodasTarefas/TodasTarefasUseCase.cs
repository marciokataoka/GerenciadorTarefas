﻿using GerenciadorDeTarefas.Communication.Responses;
using GerenciadorDeTarefas.Communication.Seed;
using System.ComponentModel.DataAnnotations.Schema;

namespace GerenciadorDeTarefas.Application.UseCase.Tarefa.TodasTarefas
{
    public class TodasTarefasUseCase
    {
        public ResponseTodasTarefasJson Execute()
        {
            var listagem = new ResponseTodasTarefasJson();

            foreach (var item in SeedTarefas.Tarefas) 
            {
                listagem.TodasTarefas.Add(item);
            }

            return listagem;
        }


    }
}
