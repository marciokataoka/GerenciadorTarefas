﻿namespace GerenciadorDeTarefas.Communication.Responses
{
    public class ResponseTodasTarefasJson
    {
        public List<ResponseTarefaJson> TodasTarefas { get; set; } = [];
    }
}
