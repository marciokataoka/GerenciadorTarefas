﻿namespace GerenciadorDeTarefas.Communication.Responses
{
    public class ResponseRegisterTarefaJson
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
