﻿namespace GerenciadorDeTarefas.Communication.Enums
{
    public enum Prioridade
    {
        Baixa,
        Media, 
        Alta
    }
}
