﻿namespace GerenciadorDeTarefas.Communication.Enums
{
    public enum Status
    {
        Concluida,
        EmAndamento,
        Aguardando
    }
}
