﻿using GerenciadorDeTarefas.Communication.Enums;

namespace GerenciadorDeTarefas.Communication.Requests
{
    public class RequestTarefaJson
    {

        public int ID { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string Descricao { get; set; } = string.Empty ;
        public Prioridade Prioridade { get; set; }
        public DateTime DataLimite { get; set; }
        public Status Status { get; set; }

    }
}
