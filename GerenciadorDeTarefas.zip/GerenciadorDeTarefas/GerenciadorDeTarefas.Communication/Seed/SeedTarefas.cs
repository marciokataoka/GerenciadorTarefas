﻿using GerenciadorDeTarefas.Communication.Enums;
using GerenciadorDeTarefas.Communication.Responses;

namespace GerenciadorDeTarefas.Communication.Seed
{
    public static class SeedTarefas
    {
        public static List<ResponseTarefaJson> Tarefas { get; set; } = [];

        public static void Seed()
        {
            Tarefas.Add(
                new ResponseTarefaJson
                {
                    ID = 1,
                    Nome = "Tarefa1",
                    Descricao = "Descricao Tarefa 1",
                    DataLimite = new DateTime(year: 2024, month: 1, day: 11),
                    Prioridade = Prioridade.Baixa,
                    Status = Status.EmAndamento
                }
            );
            Tarefas.Add(
                new ResponseTarefaJson
                {
                    ID = 2,
                    Nome = "Tarefa2",
                    Descricao = "Descricao Tarefa 2",
                    DataLimite = new DateTime(year: 2024, month: 2, day: 12),
                    Prioridade = Prioridade.Alta,
                    Status = Status.Aguardando
                }
            );
            Tarefas.Add(
                new ResponseTarefaJson
                {
                    ID = 3,
                    Nome = "Tarefa3",
                    Descricao = "Descricao Tarefa 3",
                    DataLimite = new DateTime(year: 2024, month: 3, day: 13),
                    Prioridade = Prioridade.Baixa,
                    Status = Status.Concluida
                }
            );
            Tarefas.Add(
                new ResponseTarefaJson
                {
                    ID = 4,
                    Nome = "Tarefa4",
                    Descricao = "Descricao Tarefa 4",
                    DataLimite = new DateTime(year: 2024, month: 4, day: 14),
                    Prioridade = Prioridade.Alta,
                    Status = Status.EmAndamento
                }
            );
            Tarefas.Add(
                new ResponseTarefaJson
                {
                    ID = 5,
                    Nome = "Tarefa5",
                    Descricao = "Descricao Tarefa 5",
                    DataLimite = new DateTime(year: 2024, month: 5, day: 15),
                    Prioridade = Prioridade.Media,
                    Status = Status.Aguardando
                }
            );
        }
    }
}
