﻿using Microsoft.AspNetCore.Mvc;
using GerenciadorDeTarefas.Communication.Requests;
using GerenciadorDeTarefas.Communication.Responses;
using GerenciadorDeTarefas.Application.UseCase.Tarefa.Register;
using GerenciadorDeTarefas.Application.UseCase.Tarefa.TodasTarefas;
using GerenciadorDeTarefas.Application.UseCase.Tarefa.BuscarTarefa;
using GerenciadorDeTarefas.Application.UseCase.Tarefa.Update;
using GerenciadorDeTarefas.Application.UseCase.Tarefa.Apagar;

namespace GerenciadorDeTarefas.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GerenciadorDeTarefasController : ControllerBase
    {
        [HttpPost]
        [ProducesResponseType(typeof(ResponseRegisterTarefaJson),StatusCodes.Status201Created)]
        public IActionResult CriarTarefa([FromBody] RequestTarefaJson tarefa)
        {
            var retorno = new RegisterTarefaUseCase().Execute(tarefa);

            return Ok(retorno);

        }


        [HttpGet]
        [ProducesResponseType(typeof(ResponseTodasTarefasJson),StatusCodes.Status200OK)]
        public IActionResult TodasTarefas() 
        {
            var acao = new TodasTarefasUseCase();
            return Ok(acao.Execute());

        }


        [HttpGet]
        [Route("{id}")]
        [ProducesResponseType(typeof(ResponseTarefaJson), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public IActionResult BuscarTarefa(int id) 
        {
            var retorno = new BuscarTarefaUseCase().Execute(id);
            if (retorno == null)
            {
                return NotFound($"Not Found: {id}");
            }
            else
            {
                return Ok(retorno);
            }
            
        }


        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult Update([FromBody] RequestTarefaJson tarefa)
        {
            if (tarefa == null)
            {
                return BadRequest();
            }
            else
            {
                new AtualizarTarefa().Execute(tarefa);
                return Ok();
            }
            

            
        }


        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult ApagarTarefa(int id) 
        {
            var regApagado = new ApagarTarefaUseCase().Execute(id);

            if (regApagado)
            {
                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }



    }//fim do controller
}
